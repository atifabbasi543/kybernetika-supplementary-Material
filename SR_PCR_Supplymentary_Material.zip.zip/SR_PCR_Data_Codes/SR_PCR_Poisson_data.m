clear; clc; close all;
state = 10012025;
rng(state, 'twister'); %# reproducibility%
% Define the variables and data
 data=xlsread('WNV_data.xlsx'); y=data(:,1); x=data(:,2:6);
 [n,p]=size(x);
x=(x-ones(n,1)*mean(x))./(ones(n,1)*std(x)*sqrt(n-1)); 
%  x=[ones(n,1),x];
[n,p]=size(x);
% rho= corr(x);%%% indicates that there is a multicollinearity problem
%%%% ML Estimator 
b_old=inv(x'*x)*x'*y;
mu_old=exp(x*b_old);
w_old=diag(mu_old);
z_old=x*b_old+inv(w_old)*(y-mu_old);
b_new=inv(x'*w_old*x)*x'*w_old*z_old;
for i=1:200
    mu_new=exp(x*b_new);
    w_new=diag(mu_new);
    z_new=x*b_new+inv(w_new)*(y-mu_new);
    b_new=inv(x'*w_new*x)*x'*w_new*z_new;
    if norm(b_new-b_old)<1e-6
        break;
    end
     b_old=b_new;
end

% % % Collinearity diagnostics
VIF=diag(inv(x'*w_new*x));
%%% For PCR define the following
Condition_number=cond(x'*w_new*x);
[~,S,T]=svd(x'*w_new*x);
%%%% Estimation of fi for Poisson
 fi=1;
%%% number of PCs
 z=x*T;
% pertenctage of total variance
lambda=S;
oran=0;
if (lambda(1,1)/sum(diag(lambda)))>=0.95
    Tr=T(:,1);
    r=1;
else
    Tr=T(:,1);
    for i=2:p
        if oran<0.95
            oran=sum(diag(lambda(1:i,1:i)))/sum(diag(lambda));
            Tr=[Tr T(1:p,i)];
            r=i;
        end
    end
end
r
Tr;
% Zr=x*Tr;
Tpr=T(:,r+1:p);
%%%% Stochastic restriction from Ozkale and Nyquist (2021)
     R=[0, 0, 0, 1,-1 ];
     r_1=0;
     sig=0.1;
% % % % % Test Statistic for testing the compatibility of prior and sample
% information
 % % % % % Test Statistic for testing the compatibility of prior and sample information
% % % % % (Section 4)

% 1. Delta = gamma - R * beta_ML
delta_comp = r_1 - R * b_new;

% 2. Variance of ML estimator: a(phi) * (X'WX)^{-1}
Var_b_ml = fi * inv(x' * w_new * x);

% 3. Z = a(phi) * R * (X'WX)^{-1} * R' + Sigma
Z_comp = R * Var_b_ml * R' + sig;

% 4. Test statistic: delta' * Z^{-1} * delta
gamma_star_hat = delta_comp' * (Z_comp \ delta_comp);

% 5. Degrees of freedom (number of stochastic restrictions)
q_df = size(R,1);

% 6. p-value
p_value_comp = 1 - chi2cdf(gamma_star_hat, q_df);

% Display results
fprintf('Compatibility Test Statistic (gamma*): %.6f\n', gamma_star_hat);
fprintf('Degrees of Freedom: %d\n', q_df);
fprintf('P-value: %.6f\n', p_value_comp);

 %%%%%%%%%%%PCR component estimator in GLM
beta_pcr_old=Tr*Tr'*inv(x'*x)*x'*y;
mu_pcr_old=exp(x*Tr*Tr'*beta_pcr_old);
w_pcr_old=diag(mu_pcr_old);
z_pcr_old=x*Tr*Tr'*beta_pcr_old+inv(w_pcr_old)*(y-mu_pcr_old);
beta_pcr_new=Tr*inv(Tr'*x'*w_pcr_old*x*Tr)*Tr'*x'*w_pcr_old*z_pcr_old;
for i=1:200
    mu_pcr_new=exp(x*Tr*Tr'*beta_pcr_new);
     w_pcr_new=diag(mu_pcr_new);
    z_pcr_new=x*Tr*Tr'*beta_pcr_new+inv(w_pcr_new)*(y-mu_pcr_new);
    beta_pcr_new=Tr*inv(Tr'*x'*w_pcr_new*x*Tr)*Tr'*x'*w_pcr_new*z_pcr_new;
    if norm(beta_pcr_new-beta_pcr_old)<1e-6
        break
    end
    beta_pcr_old=beta_pcr_new;    
end
beta_pcr_new;

 %%%%% For the SRPC and Mixed Estimators 
  H=R;
  h=r_1;
  Hr=H*Tr;
   %%%% Mixed Estimator in GLM
b_mixed_old=inv(x'*x)*x'*y;
mu_mixed_old=exp(x*b_mixed_old);
w_mixed_old=diag(mu_mixed_old); 
z_mixed_old=x*b_mixed_old+inv(w_mixed_old)*(y-mu_mixed_old);
b_mixed_new=inv(x'*w_mixed_old*x)*(x'*w_mixed_old*z_mixed_old)+inv(x'*w_mixed_old*x)*H'*inv(sig+H*inv(x'*w_mixed_old*x)*H')*(h-H*inv(x'*w_mixed_old*x)*x'*w_mixed_old*z_mixed_old);
for i=1:200
    mu_mixed_new=exp(x*b_mixed_new);
    w_mixed_new=diag(mu_mixed_new);
    z_mixed_new=x*b_mixed_new+inv(w_mixed_new)*(y-mu_mixed_new);
    b_mixed_new=inv(x'*w_mixed_new*x)*(x'*w_mixed_new*z_mixed_new)+inv(x'*w_mixed_new*x)*H'*inv(sig+H*inv(x'*w_mixed_new*x)*H')*(h-H*inv(x'*w_mixed_new*x)*x'*w_mixed_new*z_mixed_new);
    if norm(b_mixed_new-b_mixed_old)<1e-6
        break;
    end
 b_mixed_old=b_mixed_new;
 b_mixed_new;
end
 %%%%%%%%%%%SRPC component estimator in GLM
beta_srpc_old=Tr*Tr'*inv(x'*x)*x'*y;
mu_srpc_old=exp(x*Tr*Tr'*beta_srpc_old);
w_srpc_old=diag(mu_srpc_old);
z_srpc_old=x*Tr*Tr'*beta_srpc_old+inv(w_srpc_old)*(y-mu_srpc_old);
beta_srpc_new=Tr*inv(Tr'*x'*w_srpc_old*x*Tr)*Tr'*x'*w_srpc_old*z_srpc_old-Tr*inv(Tr'*x'*w_srpc_old*x*Tr)*Hr'*inv(sig+Hr*inv(Tr'*x'*w_srpc_old*x*Tr)*Hr')*(Hr*inv(Tr'*x'*w_srpc_old*x*Tr)*Tr'*x'*w_srpc_old*z_srpc_old-h);
for i=1:200
    mu_srpc_new=exp(x*Tr*Tr'*beta_srpc_new);
    w_srpc_new=diag(mu_srpc_new);
    z_srpc_new=x*Tr*Tr'*beta_srpc_new+inv(w_srpc_new)*(y-mu_srpc_new);
    beta_srpc_new=Tr*inv(Tr'*x'*w_srpc_new*x*Tr)*Tr'*x'*w_srpc_new*z_srpc_new-Tr*inv(Tr'*x'*w_srpc_new*x*Tr)*Hr'*inv(sig+Hr*inv(Tr'*x'*w_srpc_new*x*Tr)*Hr')*(Hr*inv(Tr'*x'*w_srpc_new*x*Tr)*Tr'*x'*w_srpc_new*z_srpc_new-h);
    if norm(beta_srpc_new-beta_srpc_old)<1e-6
        break
    end
    beta_srpc_old=beta_srpc_new;    
end
beta_srpc_new;
format long
estimators=[b_new b_mixed_new beta_pcr_new beta_srpc_new]

% Fitted mean responses
mu_ML    = exp(x*b_new);
mu_ME    = exp(x*b_mixed_new);
mu_PCR   = exp(x*Tr*Tr'*beta_pcr_new);
mu_SRPCR = exp(x*Tr*Tr'*beta_srpc_new);
% Poisson Deviance
Dev_ML    = 2*sum(y.*log(max(y,eps)./mu_ML) - (y-mu_ML));
Dev_ME    = 2*sum(y.*log(max(y,eps)./mu_ME) - (y-mu_ME));
Dev_PCR   = 2*sum(y.*log(max(y,eps)./mu_PCR) - (y-mu_PCR));
Dev_SRPCR = 2*sum(y.*log(max(y,eps)./mu_SRPCR) - (y-mu_SRPCR));

% Poisson Log-Likelihood
LogLik_ML    = sum(y.*log(mu_ML)    - mu_ML    - gammaln(y+1));
LogLik_ME    = sum(y.*log(mu_ME)    - mu_ME    - gammaln(y+1));
LogLik_PCR   = sum(y.*log(mu_PCR)   - mu_PCR   - gammaln(y+1));
LogLik_SRPCR = sum(y.*log(mu_SRPCR) - mu_SRPCR - gammaln(y+1));

format long
Deviance = [Dev_ML Dev_ME Dev_PCR Dev_SRPCR]
LogLikelihood = [LogLik_ML LogLik_ME LogLik_PCR LogLik_SRPCR]
% Check fitted mean ranges
[min(mu_ML) max(mu_ML)];
[min(mu_ME) max(mu_ME)];
[min(mu_PCR) max(mu_PCR)];
[min(mu_SRPCR) max(mu_SRPCR)];

% Check observed response range
[min(y) max(y)];
%%%%%%% For Poisson response fi=1
 fi=1;
%%%% SMSE of the Estimators
smse_ML=trace(fi*inv(x'*w_new*x));
%%%%% SMSE of the PCR Estimator 
smse_pcr=trace(fi*Tr*inv(Tr'*x'*w_new*x*Tr)*Tr'+(Tr*Tr'-eye(p))*b_new*b_new'*(Tr*Tr'-eye(p)));
%%%%% SMSE of the Mixed Estimator 
smse_mixed=trace(fi*inv(x'*w_new*x+R'*inv(sig)*R));
%%% sMSE of first order stochastic restricted PCR estimator in GLMs
smse_srpc=trace(fi*Tr*inv(Tr'*x'*w_srpc_new*x*Tr+Hr'*inv(sig)*Hr)*Tr'+Tpr*Tpr'* beta_srpc_new* beta_srpc_new'*Tpr*Tpr');
format long
smse=[smse_ML smse_mixed smse_pcr smse_srpc]

%%%%%% Relative Efficiency (RE) with respect to SR-PCR (denominator)

RE_ML     = smse_ML     / smse_srpc;
RE_Mixed = smse_mixed / smse_srpc;
RE_PCR   = smse_pcr   / smse_srpc;
RE_SRPC  = smse_srpc / smse_srpc;   

format long
RE = [RE_ML RE_Mixed RE_PCR RE_SRPC]
