
clc; clear all;
state = 10012025;
rng(state, 'twister'); %# Use rng instead of randn('state', state) for reproducibility

% % % initializing the parameter values
n=50; gama=sqrt(0.95); p=2; MCN=1000; 
mse_ml=0; mse_pcr=0; mse_mixed=0; mse_srpc=0;
pmse_ml=0; pmse_pcr=0; pmse_mixed=0; pmse_srpc=0;

u=normrnd(0,1,[n,p+1]); %% u is distributed from standard normal distribution

X = zeros(n, p);
for i=1:n
    for j=1:p
        x=sqrt((1-gama^2))*u(i,j)+gama*u(i,p+1);
        X(i,j)=x;
    end
end

% % % By standardizing the x
x=(X-ones(n,1)*mean(X))./(ones(n,1)*std(X)*sqrt(n-1));
[D,L]=eig(x'*x);
[a,b]=max(diag(L));
beta=D(:,b);

for i=1:MCN
    m=exp(x*beta);
    y=gamrnd(1,exp(x*beta));
    
    %%%% ML Estimator 
    b_old=inv(x'*x)*x'*y;
    mu_old=exp(x*b_old);
    w_old=diag(mu_old.^2); 
    z_old=log(mu_old)+(y-mu_old)./mu_old;
    b_new=inv(x'*w_old*x)*x'*w_old*z_old;
    
    for iter=1:200
        mu_new=exp(x*b_new);
        w_new=diag(mu_new.^2);
        z_new=log(mu_new)+(y-mu_new)./mu_new;
        b_new=inv(x'*w_new*x)*x'*w_new*z_new;
        if norm(b_new-b_old)<1e-6
            break;
        end
        b_old=b_new;
    end
    m_new=exp(x*b_new);
    
    %%% For PCR define the following
    [~,S,T]=svd(x'*w_new*x);
    
    lambda=S;
    oran=0;
    if (lambda(1,1)/sum(diag(lambda)))>=0.95
        Tr=T(:,1);
        r=1;
    else
        Tr=T(:,1);
        for k=2:p
            if oran<0.95
                oran=sum(diag(lambda(1:k,1:k)))/sum(diag(lambda));
                Tr=[Tr T(:,k)];
                r=k;
            end
        end
    end

    % =========================================================================
    % UNBIASED STOCHASTIC RESTRICTIONS (CONSISTENT WITH DGP: E[h] = R*beta)
    % =========================================================================
    switch p
        case 2
            R = [1 -1];
            sig = 1;
        case 4
            R = [1 -1 0 0; 
                 0 1 -1 0; 
                 0 0 1 -1];
            sig = eye(3);
        case 8
            R = [1 0 -2 1 1 1 -1 -1; 
                 1 -1 -1 1 1 -2 0 1];
            sig = eye(2);
        case 12
            R = [1 0 -2 1 1 1 -1 -1 0 1 -2 1; 
                 1 -1 1 -1 1 0 -2 1 -1 -1 1 1];
            sig = eye(2);
    end

    % Generate stochastic restriction noise vector v ~ N(0, sig)
    v = normrnd(0, sqrt(diag(sig)));
    if isrow(v)
        v = v';
    end

    % Define DGP-consistent restriction vector h
    h = R * beta + v;
    
    H = R;
    Hr = H * Tr;
    % =========================================================================

    %%%%%%%%%% PCR component estimator in GLM
    beta_pcr_old=Tr*Tr'*inv(x'*x)*x'*y;
    mu_pcr_old=exp(x*Tr*Tr'*beta_pcr_old);
    w_pcr_old=diag(mu_pcr_old.^2);
    z_pcr_old=log(mu_pcr_old)+(y-mu_pcr_old)./mu_pcr_old;

    beta_pcr_new=Tr*inv(Tr'*x'*w_pcr_old*x*Tr)*Tr'*x'*w_pcr_old*z_pcr_old;
    for iter=1:200
        mu_pcr_new=exp(x*beta_pcr_new);
        w_pcr_new=diag(mu_pcr_new.^2);
        z_pcr_new=log(mu_pcr_new)+(y-mu_pcr_new)./mu_pcr_new;
        beta_pcr_new=Tr*inv(Tr'*x'*w_pcr_new*x*Tr)*Tr'*x'*w_pcr_new*z_pcr_new;
        if norm(beta_pcr_new-beta_pcr_old)<1e-6
            break
        end
        beta_pcr_old=beta_pcr_new;    
    end
    m_pcr_new=exp(x*beta_pcr_new);

    %%%% Mixed Estimator in GLM
    b_mixed_old=inv(x'*x)*x'*y;
    mu_mixed_old=exp(x*b_mixed_old);
    w_mixed_old=diag(mu_mixed_old.^2); 
    z_mixed_old=log(mu_mixed_old)+(y-mu_mixed_old)./mu_mixed_old;
    b_mixed_new=inv(x'*w_mixed_old*x)*(x'*w_mixed_old*z_mixed_old)+...
        inv(x'*w_mixed_old*x)*H'*inv(sig+H*inv(x'*w_mixed_old*x)*H')*(h-H*inv(x'*w_mixed_old*x)*x'*w_mixed_old*z_mixed_old);

    for iter=1:200
        mu_mixed_new=exp(x*b_mixed_new);
        w_mixed_new=diag(mu_mixed_new.^2);
        z_mixed_new=log(mu_mixed_new)+(y-mu_mixed_new)./mu_mixed_new;
        b_mixed_new=inv(x'*w_mixed_new*x)*(x'*w_mixed_new*z_mixed_new)+...
            inv(x'*w_mixed_new*x)*H'*inv(sig+H*inv(x'*w_mixed_new*x)*H')*(h-H*inv(x'*w_mixed_new*x)*x'*w_mixed_new*z_mixed_new);
        if norm(b_mixed_new-b_mixed_old)<1e-6
            break;
        end
        b_mixed_old=b_mixed_new;
    end
    m_mixed=exp(x*b_mixed_new);

    %%%%%%%%%%% SRPC component estimator in GLM
    beta_srpc_old=Tr*Tr'*inv(x'*x)*x'*y;
    mu_srpc_old=exp(x*Tr*Tr'*beta_srpc_old);
    w_srpc_old=diag(mu_srpc_old.^2);
    z_srpc_old=log(mu_srpc_old)+(y-mu_srpc_old)./mu_srpc_old;
    beta_srpc_new=Tr*inv(Tr'*x'*w_srpc_old*x*Tr)*Tr'*x'*w_srpc_old*z_srpc_old-...
        Tr*inv(Tr'*x'*w_srpc_old*x*Tr)*Hr'*inv(sig+Hr*inv(Tr'*x'*w_srpc_old*x*Tr)*Hr')*(Hr*inv(Tr'*x'*w_srpc_old*x*Tr)*Tr'*x'*w_srpc_old*z_srpc_old-h);

    for iter=1:200 
        mu_srpc_new=exp(x*beta_srpc_new);
        w_srpc_new=diag(mu_srpc_new.^2);
        z_srpc_new=log(mu_srpc_new)+(y-mu_srpc_new)./mu_srpc_new;
        beta_srpc_new=Tr*inv(Tr'*x'*w_srpc_new*x*Tr)*Tr'*x'*w_srpc_new*z_srpc_new-...
            Tr*inv(Tr'*x'*w_srpc_new*x*Tr)*Hr'*inv(sig+Hr*inv(Tr'*x'*w_srpc_new*x*Tr)*Hr')*(Hr*inv(Tr'*x'*w_srpc_new*x*Tr)*Tr'*x'*w_srpc_new*z_srpc_new-h);
        if norm(beta_srpc_new-beta_srpc_old)<1e-6
            break
        end
        beta_srpc_old=beta_srpc_new;
    end
    m_srpc_new=exp(x*beta_srpc_new);

    % % mse for ML estimator
    mse_ml=mse_ml+(b_new-beta)'*(b_new-beta);
    pmse_ml=pmse_ml+(m_new-m)'*(m_new-m);

    % % mse for pcr estimator
    mse_pcr=mse_pcr+(beta_pcr_new-beta)'*(beta_pcr_new-beta);
    pmse_pcr=pmse_pcr+(m_pcr_new-m)'*(m_pcr_new-m);

    % % mse for mixed estimator
    mse_mixed=mse_mixed+(b_mixed_new-beta)'*(b_mixed_new-beta); 
    pmse_mixed=pmse_mixed+(m_mixed-m)'*(m_mixed-m);

    % % mse for srpc estimator
    mse_srpc=mse_srpc+(beta_srpc_new-beta)'*(beta_srpc_new-beta);
    pmse_srpc=pmse_srpc+(m_srpc_new-m)'*(m_srpc_new-m);
end

mse_ml=mse_ml/MCN;
mse_pcr=mse_pcr/MCN;
mse_mixed=mse_mixed/MCN;
mse_srpc=mse_srpc/MCN;

format long
mse=[mse_ml mse_pcr mse_mixed mse_srpc] 

%%%% PMSE
pmse_ml=pmse_ml/MCN;
pmse_pcr=pmse_pcr/MCN;
pmse_mixed=pmse_mixed/MCN;
pmse_srpc=pmse_srpc/MCN;

pmse=[pmse_ml pmse_pcr pmse_mixed pmse_srpc]
